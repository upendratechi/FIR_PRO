import os
import sys

# Add the project directory to the sys.path
project_home = '/home/danlawtechu/FIR_PRO'
if project_home not in sys.path:
    sys.path = [project_home] + sys.path

# Set the DJANGO_SETTINGS_MODULE environment variable
os.environ['DJANGO_SETTINGS_MODULE'] = 'psn_project.settings'

# Activate the virtual environment
activate_env = os.path.expanduser('/home/danlawtechu/myenv/bin/activate_this.py')
with open(activate_env) as f:
    exec(f.read(), {'__file__': activate_env})

# Import the WSGI application
from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()
