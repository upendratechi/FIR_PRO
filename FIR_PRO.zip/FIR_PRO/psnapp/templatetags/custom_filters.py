from django import template

register = template.Library()

@register.filter
def not_in(value, arg):
    return value not in arg.split(',')